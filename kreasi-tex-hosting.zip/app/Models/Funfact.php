<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Funfact extends Model
{
    //
    protected $fillable = ["text1", "text2", "title1", "title2", "link_instagram"];
}
