<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GambarAbout extends Model
{
    protected $fillable = [
        'gambar'
    ];
}
